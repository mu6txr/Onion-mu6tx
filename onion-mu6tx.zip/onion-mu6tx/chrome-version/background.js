const PROXY_CONFIG = {
  mode: "fixed_servers",
  rules: {
    singleProxy: { scheme: "socks5", host: "127.0.0.1", port: 9050 },
    bypassList: ["localhost", "127.0.0.1"]
  }
};

function enableProxy(cb) {
  chrome.proxy.settings.set({ value: PROXY_CONFIG, scope: 'regular' }, () => {
    chrome.storage.local.set({ torStatus: 'on' });
    if (cb) cb(true);
  });
}

function disableProxy(cb) {
  chrome.proxy.settings.set({ value: { mode: 'direct' }, scope: 'regular' }, () => {
    chrome.storage.local.set({ torStatus: 'off' });
    if (cb) cb(true);
  });
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get('torStatus', (data) => {
    if (!data.torStatus) chrome.storage.local.set({ torStatus: 'off' });
  });
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "toggleTor") {
    if (request.status === 'on') enableProxy(() => sendResponse({ success: true }));
    else disableProxy(() => sendResponse({ success: true }));
    return true;
  }
  if (request.action === "getStatus") {
    chrome.storage.local.get('torStatus', (data) => {
      sendResponse({ status: data.torStatus || 'off' });
    });
    return true;
  }
});
