document.addEventListener('DOMContentLoaded', function () {
  const toggle = document.getElementById('torToggle');
  const statusText = document.getElementById('statusText');
  const statusDot = document.getElementById('statusDot');

  chrome.runtime.sendMessage({ action: 'getStatus' }, (response) => {
    if (response && response.status === 'on') {
      toggle.checked = true;
      updateUI(true);
    } else {
      toggle.checked = false;
      updateUI(false);
    }
  });

  toggle.addEventListener('change', function () {
    const isChecked = this.checked;
    this.disabled = true;
    if (isChecked) {
      chrome.runtime.sendMessage({ action: 'toggleTor', status: 'on' }, () => {
        updateUI(true);
        toggle.disabled = false;
      });
    } else {
      chrome.runtime.sendMessage({ action: 'toggleTor', status: 'off' }, () => {
        updateUI(false);
        toggle.disabled = false;
      });
    }
  });

  function updateUI(isOn) {
    if (isOn) {
      statusText.textContent = 'متصل عبر Tor';
      statusDot.className = 'status-indicator on';
    } else {
      statusText.textContent = 'غير متصل';
      statusDot.className = 'status-indicator off';
    }
  }
});
