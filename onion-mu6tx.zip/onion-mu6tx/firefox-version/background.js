let isProxyEnabled = false;

function enableProxy() {
  if (!isProxyEnabled) {
    browser.proxy.onRequest.addListener(handleProxyRequest, { urls: ["<all_urls>"] });
    isProxyEnabled = true;
    browser.storage.local.set({ torStatus: 'on' });
  }
}

function disableProxy() {
  if (isProxyEnabled) {
    browser.proxy.onRequest.removeListener(handleProxyRequest);
    isProxyEnabled = false;
    browser.storage.local.set({ torStatus: 'off' });
  }
}

function handleProxyRequest(requestInfo) {
  return { type: "socks", host: "127.0.0.1", port: 9050, proxyDNS: true };
}

browser.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "toggleTor") {
    if (request.status === 'on') enableProxy();
    else disableProxy();
    sendResponse({ success: true });
  }
  if (request.action === "getStatus") {
    browser.storage.local.get('torStatus', (data) => {
      sendResponse({ status: data.torStatus || 'off' });
    });
    return true;
  }
});

browser.storage.local.get('torStatus', (data) => {
  if (data.torStatus === 'on') enableProxy();
});
